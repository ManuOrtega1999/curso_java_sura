package com.sura.bibloteca.repository;

import com.sura.bibloteca.entity.ElementoPrestableBaseEntity;
import com.sura.bibloteca.entity.EmpleadoEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface IempleadoRepository extends JpaRepository<EmpleadoEntity,Integer> {

    @Query(value = "select * from empleado where id_empleado = :idEmpleado", nativeQuery = true)
    EmpleadoEntity findById(@Param("idEmpleado") int idEmpleado);

}

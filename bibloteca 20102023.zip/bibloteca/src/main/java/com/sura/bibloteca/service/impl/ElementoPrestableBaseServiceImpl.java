package com.sura.bibloteca.service.impl;

import com.sura.bibloteca.dto.ElementoPrestableBaseDTO;
import com.sura.bibloteca.entity.ElementoPrestableBaseEntity;
import com.sura.bibloteca.mapping.ElementoPrestableBaseMapping;
import com.sura.bibloteca.repository.IelementoPrestableBaseRepository;
import com.sura.bibloteca.service.IelementoPrestableBaseService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
@AllArgsConstructor
public class ElementoPrestableBaseServiceImpl implements IelementoPrestableBaseService {


    private final IelementoPrestableBaseRepository elementoPrestableBaseRepository;

    @Override
    public ElementoPrestableBaseDTO crearElementoPrestableBase(ElementoPrestableBaseDTO elementoPrestableBaseDTO) {
        ElementoPrestableBaseEntity buscarTitulo = elementoPrestableBaseRepository.findByTitulo(elementoPrestableBaseDTO.getTitulo());
        if (Objects.isNull(buscarTitulo)){
            ElementoPrestableBaseEntity crearElemento = elementoPrestableBaseRepository.saveAndFlush(new ElementoPrestableBaseMapping()
                    .ElementoPrestableBaseDtoToElementoPrestableBaseEntity(elementoPrestableBaseDTO));
            if (Objects.nonNull(crearElemento)){
                ElementoPrestableBaseDTO prestableBaseDTO = new ElementoPrestableBaseMapping().ElementoPrestableBaseEntityToElementoPrestableBaseDto(crearElemento);
                return prestableBaseDTO;
            }
        }
        return null;

    }

    @Override
    public ElementoPrestableBaseDTO actualizarElementoPrestableBase(ElementoPrestableBaseDTO elementoPrestableBaseDTO) {
        Optional<ElementoPrestableBaseEntity> buscarElemento = elementoPrestableBaseRepository.findById(elementoPrestableBaseDTO.getIdElementoPrestableBase());
        if (Objects.nonNull(buscarElemento.get())){
            ElementoPrestableBaseEntity actualizarElemento = elementoPrestableBaseRepository.saveAndFlush(new ElementoPrestableBaseMapping()
                    .ElementoPrestableBaseDtoToElementoPrestableBaseEntity(elementoPrestableBaseDTO) );
            if (Objects.nonNull(actualizarElemento)){
                ElementoPrestableBaseDTO actualizarElementoPrestableBaseDto = new ElementoPrestableBaseMapping().ElementoPrestableBaseEntityToElementoPrestableBaseDto(actualizarElemento);
                return actualizarElementoPrestableBaseDto;
            }
        }
        return null;
    }

    @Override
    public ElementoPrestableBaseDTO buscarElementoPrestableBase(Integer idElementoPrestableBaseDTO) {
        Optional<ElementoPrestableBaseEntity> buscarElemento = elementoPrestableBaseRepository.findById(idElementoPrestableBaseDTO);
        if (Objects.nonNull(buscarElemento.get())){
            ElementoPrestableBaseDTO buscarElementoPrestableDto = new ElementoPrestableBaseMapping().ElementoPrestableBaseEntityToElementoPrestableBaseDto(buscarElemento.get());
            return  buscarElementoPrestableDto;
        }
        return null;
    }

    @Override
    public String borrarElementoPrestableBase(ElementoPrestableBaseDTO elementoPrestableBaseDTO) {
        ElementoPrestableBaseDTO buscarElementoPrestableDto = buscarElementoPrestableBase(elementoPrestableBaseDTO.getIdElementoPrestableBase());
        if (Objects.nonNull(buscarElementoPrestableDto)){
            elementoPrestableBaseRepository.delete(new ElementoPrestableBaseMapping().ElementoPrestableBaseDtoToElementoPrestableBaseEntity(elementoPrestableBaseDTO));
            return  "EL elemento fue borrado exitosamente";
        }
        return null;
    }

    @Override
    public List<ElementoPrestableBaseDTO> buscarTodosElementosPestablesBase() {
        List<ElementoPrestableBaseEntity> elementoPrestableBaseEntity = elementoPrestableBaseRepository.findAll();
        if (!elementoPrestableBaseEntity.isEmpty() && elementoPrestableBaseEntity.size()>0){
            List<ElementoPrestableBaseDTO> elementoPrestableBaseDTOS = new ElementoPrestableBaseMapping().
                    listElementoPrestableBaseEntityToElementoPrestableBaseDto(elementoPrestableBaseEntity);
            return elementoPrestableBaseDTOS;
        }
        return null;
    }
}

package com.sura.bibloteca.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "revista")
public class RevistaEntity {

    @EmbeddedId
    private RevistaIdEntity revistaId;

    //@ManyToOne(fetch = FetchType.LAZY, optional = false)
    //@JoinColumn(name = "id_elemento_prestable_base", nullable = false)
    //private ElementoPrestableBaseEntity idElementoPrestableBase;
}

package com.sura.bibloteca.mapping;

import com.sura.bibloteca.dto.UsuarioDTO;
import com.sura.bibloteca.entity.UsuarioEntity;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@NoArgsConstructor
public class UsuarioMapping {

    public UsuarioEntity UsuarioDtoToUsuarioEntity(UsuarioDTO usuarioDTO){
        return UsuarioEntity.builder()
                .idUsuario(usuarioDTO.getIdUsuario())
                .limite_prestamos(usuarioDTO.getLimite_prestamos())
                .build();
    }
    public UsuarioDTO UsuarioEntityToUsuarioDto(UsuarioEntity usuarioEntity){
        return UsuarioDTO.builder()
                .idUsuario(usuarioEntity.getIdUsuario())
                .limite_prestamos(usuarioEntity.getLimite_prestamos())
                .build();
    }

    public List<UsuarioDTO> listUsuarioEntityToUsuarioDto(List<UsuarioEntity> entities){
        List<UsuarioDTO> UsuarioDTOS = new ArrayList<>();
        entities.forEach(UsuarioEntity -> {
            UsuarioDTO usuarioDTO = UsuarioEntityToUsuarioDto(UsuarioEntity);
            UsuarioDTOS.add(usuarioDTO);
        });
        return UsuarioDTOS;
    }
}

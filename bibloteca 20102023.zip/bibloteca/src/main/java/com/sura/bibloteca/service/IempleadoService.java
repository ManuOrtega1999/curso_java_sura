package com.sura.bibloteca.service;

import com.sura.bibloteca.dto.EmpleadoDTO;
import com.sura.bibloteca.dto.UsuarioDTO;

import java.util.List;

public interface IempleadoService {
    EmpleadoDTO crearEmpleado(EmpleadoDTO empleadoDTO);

    EmpleadoDTO actualizarEmpleado(EmpleadoDTO empleadoDTO);

    EmpleadoDTO buscarEmpleado(Integer idEmpleadoDTO);

    String borrarEmpleado(EmpleadoDTO empleadoDTO);

    List<EmpleadoDTO> buscarTodosEmpleados();
}

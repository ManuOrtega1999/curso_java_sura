package com.sura.bibloteca.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Builder
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "comentario")
public class ComentarioEntity {

    @Id
    @Column(name = "id_cometario",nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_cometario;

    @Column(name = "id_usuario",nullable = false)
    private Integer id_usuario;

    @Column(name = "id_elemento_prestable_base",nullable = false)
    private Integer id_elemento_prestable_base;

    @Column(name = "comentario",nullable = false)
    private String comentario;

    @Column(name = "clalificacion",nullable = false)
    private String clalificacion;

    @ManyToOne (fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "ElementoPrestableBaseEntity_idElementoPrestableBase", nullable = false)
    private ElementoPrestableBaseEntity elementoPrestableBaseEntity;

    @ManyToOne (fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "UsuarioEntity_idUsuario", nullable = false)
    private UsuarioEntity usuarioEntityIdUsuario;

}

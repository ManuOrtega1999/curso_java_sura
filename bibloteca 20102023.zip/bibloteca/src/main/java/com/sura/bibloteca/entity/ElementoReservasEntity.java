package com.sura.bibloteca.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Builder
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "elemento_reservas")
public class ElementoReservasEntity {

    @Id
    @Column(name = "id_reserva",nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_reserva;

    @Column(name = "id_elemento_prestable_base",nullable = false)
    private Integer id_elemento_prestable_base;

    @Column(name = "id_empleado",nullable = false)
    private Integer id_empleado;

    @Column(name = "id_usuario",nullable = false)
    private Integer id_usuario;

    @Column(name = "reservado",nullable = false)
    private Boolean reservado;

    @Column(name = "fecha_reserva",nullable = false)
    private LocalDate fecha_reserva;

    @ManyToOne (fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "ElementoPrestableBaseEntity_idElementoPrestableBase", nullable = false)
    private ElementoPrestableBaseEntity elementoPrestableBaseEntity;

    @ManyToOne (fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "EmpleadoEntity_idEmpleado", nullable = false)
    private EmpleadoEntity empleadoEntityIdEmpleado;

    @ManyToOne (fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "UsuarioEntity_idUsuario", nullable = false)
    private UsuarioEntity usuarioEntityIdUsuario;
}

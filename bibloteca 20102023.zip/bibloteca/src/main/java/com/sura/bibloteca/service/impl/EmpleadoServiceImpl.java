package com.sura.bibloteca.service.impl;

import com.sura.bibloteca.dto.EmpleadoDTO;
import com.sura.bibloteca.dto.UsuarioDTO;
import com.sura.bibloteca.entity.EmpleadoEntity;
import com.sura.bibloteca.entity.UsuarioEntity;
import com.sura.bibloteca.mapping.EmpleadoMapping;
import com.sura.bibloteca.mapping.UsuarioMapping;
import com.sura.bibloteca.repository.IempleadoRepository;
import com.sura.bibloteca.repository.IusuarioRepository;
import com.sura.bibloteca.service.IempleadoService;
import com.sura.bibloteca.service.IusuarioService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
@AllArgsConstructor
public class EmpleadoServiceImpl implements IempleadoService{

    private final IempleadoRepository empleadoRepository;

    @Override
    public EmpleadoDTO crearEmpleado(EmpleadoDTO empleadoDTO) {
        EmpleadoEntity crearElemento = empleadoRepository.saveAndFlush(new EmpleadoMapping()
                    .EmpleadoDtoToEmpleadoEntity(empleadoDTO));
            if (Objects.nonNull(crearElemento)){
                EmpleadoDTO suarioDTO = new EmpleadoMapping().EmpleadoEntityToEmpleadoDto(crearElemento);
                return suarioDTO;
        }
        return null;
    }

    @Override
    public EmpleadoDTO actualizarEmpleado(EmpleadoDTO empleadoDTO) {
        Optional<EmpleadoEntity> buscarElemento = empleadoRepository.findById(empleadoDTO.getIdEmpleado());
        if (Objects.nonNull(buscarElemento.get())){
            EmpleadoEntity actualizarElemento = empleadoRepository.saveAndFlush(new EmpleadoMapping()
                    .EmpleadoDtoToEmpleadoEntity(empleadoDTO));
            if (Objects.nonNull(actualizarElemento)){
                EmpleadoDTO actualizarEmpleadoDto = new EmpleadoMapping().EmpleadoEntityToEmpleadoDto(actualizarElemento);
                return actualizarEmpleadoDto;
            }
        }

        return null;
    }

    @Override
    public EmpleadoDTO buscarEmpleado(Integer idEmpleadoDTO) {
        Optional<EmpleadoEntity> buscarElemento = empleadoRepository.findById(idEmpleadoDTO);
        if (Objects.nonNull(buscarElemento.get())) {
            EmpleadoDTO buscarEmpleadoDto = new EmpleadoMapping().EmpleadoEntityToEmpleadoDto(buscarElemento.get());
            return buscarEmpleadoDto ;
        }
        return null;
    }

    @Override
    public String borrarEmpleado(EmpleadoDTO empleadoDTO) {
        EmpleadoDTO buscarEmpleadoDto = buscarEmpleado(empleadoDTO.getIdEmpleado());
        if (Objects.nonNull(buscarEmpleadoDto)){
            empleadoRepository.delete(new EmpleadoMapping().EmpleadoDtoToEmpleadoEntity(empleadoDTO));
            return  "EL elemento fue borrado exitosamente";
        }
        return null;
    }

    @Override
    public List<EmpleadoDTO> buscarTodosEmpleados() {
        List<EmpleadoEntity> EmpleadoEntity = empleadoRepository.findAll();
        if (!EmpleadoEntity.isEmpty() && EmpleadoEntity.size()>0){
            List<EmpleadoDTO> empleadoDTOS = new EmpleadoMapping()
                    .listEmpleadoEntityToEmpleadoDto(EmpleadoEntity);
            return empleadoDTOS;
        }

        return null;
    }
}

package com.sura.bibloteca.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "pelicula")
public class PeliculaEntity {

    @EmbeddedId
    private PeliculaIdEntity peliculaId;

    @Column(name = "director",nullable = false)
    private String director;

    @Column(name = "reparto",nullable = false)
    private String reparto;

    @Column(name = "duracion",nullable = false)
    private float duracion;

    //@ManyToOne(fetch = FetchType.LAZY, optional = false)
    //@JoinColumn(name = "id_elemento_prestable_base", nullable = false)
    //private ElementoPrestableBaseEntity idElementoPrestableBase;

}

package com.sura.bibloteca.service;

import com.sura.bibloteca.dto.UsuarioDTO;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface IusuarioService {

    UsuarioDTO crearUsuario (UsuarioDTO usuarioDTO);

    UsuarioDTO actualizarUsuario(UsuarioDTO usuarioDTO);

    UsuarioDTO buscarUsuario(Integer idUsuarioDTO);

    String borrarUsuario(UsuarioDTO usuarioDTO);

    List<UsuarioDTO> buscarTodosUsuarios();
}


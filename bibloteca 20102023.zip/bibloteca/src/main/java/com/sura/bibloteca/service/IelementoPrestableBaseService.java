package com.sura.bibloteca.service;

import com.sura.bibloteca.dto.ElementoPrestableBaseDTO;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface IelementoPrestableBaseService {

    ElementoPrestableBaseDTO crearElementoPrestableBase (ElementoPrestableBaseDTO elementoPrestableBaseDTO);
    ElementoPrestableBaseDTO actualizarElementoPrestableBase(ElementoPrestableBaseDTO elementoPrestableBaseDTO);

    ElementoPrestableBaseDTO buscarElementoPrestableBase(Integer idElementoPrestableBaseDTO);

    String borrarElementoPrestableBase(ElementoPrestableBaseDTO elementoPrestableBaseDTO);

    List<ElementoPrestableBaseDTO> buscarTodosElementosPestablesBase();
}

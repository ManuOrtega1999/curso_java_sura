package com.sura.bibloteca.service.impl;

import com.sura.bibloteca.dto.UsuarioDTO;
import com.sura.bibloteca.entity.UsuarioEntity;
import com.sura.bibloteca.mapping.UsuarioMapping;
import com.sura.bibloteca.repository.IusuarioRepository;
import com.sura.bibloteca.service.IusuarioService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
@AllArgsConstructor
public class UsuarioServiceImpl  implements IusuarioService {


    private final IusuarioRepository usuarioRepository;

    @Override
    public UsuarioDTO crearUsuario(UsuarioDTO usuarioDTO) {
            UsuarioEntity crearElemento = usuarioRepository.saveAndFlush(new UsuarioMapping()
                    .UsuarioDtoToUsuarioEntity(usuarioDTO));
            if (Objects.nonNull(crearElemento)){
                UsuarioDTO suarioDTO = new UsuarioMapping().UsuarioEntityToUsuarioDto(crearElemento);
                return suarioDTO;
        }
        return null;

    }

    @Override
    public UsuarioDTO actualizarUsuario(UsuarioDTO usuarioDTO) {
        Optional<UsuarioEntity> buscarElemento = usuarioRepository.findById(usuarioDTO.getIdUsuario());
        if (Objects.nonNull(buscarElemento.get())){
            UsuarioEntity actualizarElemento = usuarioRepository.saveAndFlush(new UsuarioMapping()
                    .UsuarioDtoToUsuarioEntity(usuarioDTO));
            if (Objects.nonNull(actualizarElemento)){
                UsuarioDTO actualizarUsuarioDto = new UsuarioMapping().UsuarioEntityToUsuarioDto(actualizarElemento);
                return actualizarUsuarioDto;
            }
        }

        return null;
    }

    @Override
    public UsuarioDTO buscarUsuario(Integer idUsuarioDTO) {
        Optional<UsuarioEntity> buscarElemento = usuarioRepository.findById(idUsuarioDTO);
        if (Objects.nonNull(buscarElemento.get())) {
            UsuarioDTO buscarUsuarioDto = new UsuarioMapping().UsuarioEntityToUsuarioDto(buscarElemento.get());
            return buscarUsuarioDto ;
        }
        return null;
    }

    @Override
    public String borrarUsuario(UsuarioDTO usuarioDTO) {
        UsuarioDTO buscarUsuarioDto = buscarUsuario(usuarioDTO.getIdUsuario());
        if (Objects.nonNull(buscarUsuarioDto)){
            usuarioRepository.delete(new UsuarioMapping().UsuarioDtoToUsuarioEntity(usuarioDTO));
            return  "EL elemento fue borrado exitosamente";
        }
        return null;
    }

    @Override
    public List<UsuarioDTO> buscarTodosUsuarios() {
        List<UsuarioEntity> UsuarioEntity = usuarioRepository.findAll();
        if (!UsuarioEntity.isEmpty() && UsuarioEntity.size()>0){
            List<UsuarioDTO> usuarioDTOS = new UsuarioMapping()
                    .listUsuarioEntityToUsuarioDto(UsuarioEntity);
            return usuarioDTOS;
        }

        return null;
    }
}




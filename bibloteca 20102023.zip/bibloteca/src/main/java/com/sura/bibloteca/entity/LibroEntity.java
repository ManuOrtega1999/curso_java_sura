package com.sura.bibloteca.entity;

import jakarta.persistence.*;
import lombok.*;

@Builder
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "libro")
public class LibroEntity {

    @EmbeddedId
    private LibroIdEntity libroIdEntity;

    @Column(name = "autor", nullable = false)
    private String autor;

    @Column(name = "ediccion", nullable = false)
    private String ediccion;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "id_elemento_prestable_base", nullable = false)
    private ElementoPrestableBaseEntity idElementoPrestableBase;

}

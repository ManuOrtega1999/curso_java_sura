package com.sura.bibloteca.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sura.bibloteca.dto.ElementoPrestableBaseDTO;
import com.sura.bibloteca.dto.UsuarioDTO;
import com.sura.bibloteca.service.IusuarioService;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@AllArgsConstructor
@RestController
@RequestMapping("/usuario")
@CrossOrigin(origins = "*")
@Log4j2
public class UsuarioController {

    private final IusuarioService UsuarioService;


    @ApiResponses(value =
            {
                    @ApiResponse(code = 200, message = "ok. se guardo correctamente el elemento", response = ElementoPrestableBaseDTO.class),
                    @ApiResponse(code = 400, message = "No llenaste los datos correctamente", response = String.class),
                    @ApiResponse(code = 500, message = "error inesperado del sistema")
            })

    @PostMapping(produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> guardarUsuario(@RequestBody @Validated UsuarioDTO usuarioDTO)
    {
        UsuarioDTO usuarioResponse = UsuarioService.crearUsuario(usuarioDTO);

        try {
            return ResponseEntity.status(HttpStatus.OK).body(new ObjectMapper().writeValueAsString(usuarioResponse));
        }

        catch (JsonProcessingException e)
        {
            throw new RuntimeException();
        }
    }

    @ApiResponses(value =
            {
                    @ApiResponse(code = 200, message = "ok. se guardo correctamente el elemento", response = UsuarioDTO.class),
                    @ApiResponse(code = 400, message = "No llenaste los datos correctamente", response = String.class),
                    @ApiResponse(code = 500, message = "error inesperado del sistema")
            })

    @PutMapping(produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> actualizarUsuario(@RequestBody @Validated UsuarioDTO usuarioDTO)
    {
        UsuarioDTO usuarioResponse = UsuarioService.actualizarUsuario(usuarioDTO);

        try {
            return ResponseEntity.status(HttpStatus.OK).body(new ObjectMapper().writeValueAsString(usuarioResponse));
        }

        catch (JsonProcessingException e)
        {
            throw new RuntimeException();
        }
    }

    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> buscarUsuario(@RequestParam("idUsuarioDTO") Integer idUsuarioDTO)
    {
        UsuarioDTO usuarioResponse = UsuarioService.buscarUsuario(idUsuarioDTO);

        try {
            return ResponseEntity.status(HttpStatus.OK).body(new ObjectMapper().writeValueAsString(usuarioResponse));
        }

        catch (JsonProcessingException e)
        {
            throw new RuntimeException();
        }
    }

    @ApiResponses(value =
            {
                    @ApiResponse(code = 200, message = "ok. se guardo correctamente el elemento", response = UsuarioDTO.class),
                    @ApiResponse(code = 400, message = "No llenaste los datos correctamente", response = String.class),
                    @ApiResponse(code = 500, message = "error inesperado del sistema")
            })

    @DeleteMapping(produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> borrarUsuario(@RequestBody @Validated UsuarioDTO usuarioDTO)
    {
        String usuarioResponse = UsuarioService.borrarUsuario(usuarioDTO);

        try {
            return ResponseEntity.status(HttpStatus.OK).body(new ObjectMapper().writeValueAsString(usuarioResponse));
        }

        catch (JsonProcessingException e)
        {
            throw new RuntimeException();
        }
    }

}



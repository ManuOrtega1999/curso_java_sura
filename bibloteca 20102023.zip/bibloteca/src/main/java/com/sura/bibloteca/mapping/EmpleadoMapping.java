package com.sura.bibloteca.mapping;

import com.sura.bibloteca.dto.EmpleadoDTO;
import com.sura.bibloteca.entity.EmpleadoEntity;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@NoArgsConstructor
public class EmpleadoMapping {

    public EmpleadoEntity EmpleadoDtoToEmpleadoEntity(EmpleadoDTO empleadoDTO){
        return EmpleadoEntity.builder()
                .idEmpleado(empleadoDTO.getIdEmpleado())
                .nombre(empleadoDTO.getNombre())
                .build();
    }
    public EmpleadoDTO EmpleadoEntityToEmpleadoDto(EmpleadoEntity empleadoEntity){
        return EmpleadoDTO.builder()
                .idEmpleado(empleadoEntity.getIdEmpleado())
                .nombre(empleadoEntity.getNombre())
                .build();
    }

    public List<EmpleadoDTO> listEmpleadoEntityToEmpleadoDto(List<EmpleadoEntity> entities){
        List<EmpleadoDTO> EmpleadoDTOS = new ArrayList<>();
        entities.forEach(EmpleadoEntity -> {
            EmpleadoDTO empleadoDTO = EmpleadoEntityToEmpleadoDto(EmpleadoEntity);
            EmpleadoDTOS.add(empleadoDTO);
        });
        return EmpleadoDTOS;
    }
}

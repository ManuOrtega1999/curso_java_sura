package com.sura.bibloteca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BiblotecaApplicationTests {

	@Test
	void contextLoads() {
	}

}
